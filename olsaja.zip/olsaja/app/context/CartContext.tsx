import { createContext, useState, useContext } from 'react'

// Typ položky v košíku
type CartItem = { id: number, name: string, quantity: number }

const CartContext = createContext<{
  cart: CartItem[],
  addToCart: (item: CartItem) => void
} | null>(null)

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [cart, setCart] = useState<CartItem[]>([])

  const addToCart = (item: CartItem) => {
    setCart(prev => [...prev, item])
  }

  return (
    <CartContext.Provider value={{ cart, addToCart }}>
      {children}
    </CartContext.Provider>
  )
}

// Custom hook pro použití contextu jednodušeji
export const useCart = () => {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error("Použij useCart uvnitř CartProvider")
  return ctx
}